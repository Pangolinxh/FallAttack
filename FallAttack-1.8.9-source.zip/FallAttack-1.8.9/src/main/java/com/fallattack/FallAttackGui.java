package com.fallattack;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Mouse;

import java.io.IOException;

public class FallAttackGui extends GuiScreen {
    private GuiButton toggleButton;
    private boolean draggingSlider = false;
    private final int sliderWidth = 180;

    @Override
    public void initGui() {
        buttonList.clear();
        toggleButton = new GuiButton(
            0, width / 2 - 90, height / 2 + 35, 180, 20,
            enabledText()
        );
        buttonList.add(toggleButton);
        buttonList.add(new GuiButton(1, width / 2 - 90, height / 2 + 65, 180, 20, "Done"));
    }

    private String enabledText() {
        return "FallAttack: " + (FallAttack.enabled ? "ON" : "OFF");
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) {
            FallAttack.enabled = !FallAttack.enabled;
            button.displayString = enabledText();
        } else if (button.id == 1) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        drawCenteredString(fontRendererObj, "FallAttack Settings", width / 2, height / 2 - 65, 0xFFFFFF);
        String state = FallAttack.enabled ? EnumChatFormatting.GREEN + "Enabled" : EnumChatFormatting.RED + "Disabled";
        drawCenteredString(fontRendererObj, "Attack filter: " + state, width / 2, height / 2 - 42, 0xFFFFFF);

        drawCenteredString(fontRendererObj, "Minimum downward speed: " +
            String.format("%.2f", FallAttack.minFallSpeed), width / 2, height / 2 - 10, 0xFFFFFF);

        int left = width / 2 - sliderWidth / 2;
        int top = height / 2 + 12;
        drawRect(left, top, left + sliderWidth, top + 6, 0xFF555555);

        double fraction = (FallAttack.minFallSpeed - 0.01D) / (0.50D - 0.01D);
        int knobX = left + (int)(fraction * sliderWidth);
        drawRect(knobX - 3, top - 4, knobX + 3, top + 10, 0xFFFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton == 0) {
            int left = width / 2 - sliderWidth / 2;
            int top = height / 2 + 8;
            if (mouseX >= left - 4 && mouseX <= left + sliderWidth + 4 &&
                mouseY >= top && mouseY <= top + 14) {
                draggingSlider = true;
                updateSlider(mouseX);
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        draggingSlider = false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        if (draggingSlider && Mouse.isButtonDown(0)) {
            updateSlider(Mouse.getEventX() * width / mc.displayWidth);
        }
    }

    private void updateSlider(int mouseX) {
        int left = width / 2 - sliderWidth / 2;
        double fraction = (mouseX - left) / (double) sliderWidth;
        fraction = Math.max(0.0D, Math.min(1.0D, fraction));
        FallAttack.minFallSpeed = 0.01D + fraction * 0.49D;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
