package com.fallattack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import org.lwjgl.input.Keyboard;

@Mod(
    modid = FallAttack.MODID,
    name = FallAttack.NAME,
    version = FallAttack.VERSION,
    clientSideOnly = true,
    acceptedMinecraftVersions = "[1.8.9]"
)
public class FallAttack {
    public static final String MODID = "fallattack";
    public static final String NAME = "FallAttack";
    public static final String VERSION = "1.0.0";

    public static boolean enabled = true;
    public static double minFallSpeed = 0.05D;

    private static KeyBinding openGuiKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        openGuiKey = new KeyBinding(
            "key.fallattack.gui",
            Keyboard.KEY_RSHIFT,
            "key.categories.fallattack"
        );
        ClientRegistry.registerKeyBinding(openGuiKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (openGuiKey != null && openGuiKey.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new FallAttackGui());
        }
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        EntityPlayer player = event.entityPlayer;
        Minecraft mc = Minecraft.getMinecraft();

        if (player == null || player != mc.thePlayer) return;
        if (!player.worldObj.isRemote || !enabled) return;

        boolean falling = !player.onGround && player.motionY < -minFallSpeed;
        if (!falling) {
            event.setCanceled(true);
        }
    }
}
