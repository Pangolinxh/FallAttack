# FallAttack for Minecraft 1.8.9 Forge

Client-side Forge mod for Minecraft 1.8.9.

## Features
- Right Shift opens the settings GUI.
- Enable/disable attack filtering.
- Adjust minimum downward velocity (0.01 to 0.50).
- Cancels local player attack events unless the player is airborne and moving downward faster than the configured threshold.

## Build requirements
- JDK 8 (recommended for this legacy ForgeGradle toolchain)
- Gradle 2.14.1

Run:

```bash
gradle setupDecompWorkspace
gradle build
```

The output JAR will be in `build/libs/`.

## Notes
This is a client-side event-filter implementation. It does not queue attacks made while grounded or replay them later. Server-side validation remains authoritative, and behavior can vary with server plugins and anti-cheat systems.
